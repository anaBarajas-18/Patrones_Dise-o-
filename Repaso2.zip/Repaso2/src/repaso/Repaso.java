package repaso;

import processing.core.PApplet;
import models.*;

public class Repaso extends PApplet {

    // Objetos
    Caja suelo;
    Caja edificio1;
    Caja edificio2;
    Caja edificio3;

    Circulo luna;
    Circulo ventana;

    public static void main(String[] args) {
        PApplet.main(Repaso.class);
    }

    @Override
    public void settings() {
        size(600, 600);
    }

    @Override
    public void setup() {
        rectMode(CENTER);
        ellipseMode(CENTER);

        // Suelo
        suelo = new Caja(
            new Posicion(300, 550),
            new Dimension(600, 100),
            new Borde(0, 0),
            color(20, 20, 20)
        );

        // Edificios
        edificio1 = new Caja(
            new Posicion(150, 380),
            new Dimension(100, 300),
            new Borde(0, 0),
            color(50, 50, 80)
        );

        edificio2 = new Caja(
            new Posicion(300, 350),
            new Dimension(120, 350),
            new Borde(0, 0),
            color(60, 60, 90)
        );

        edificio3 = new Caja(
            new Posicion(450, 390),
            new Dimension(90, 280),
            new Borde(0, 0),
            color(55, 55, 85)
        );

        // Luna
        luna = new Circulo(
            new Posicion(480, 100),
            40,
            new Borde(0, 0),
            color(240, 240, 255)
        );

        // Ventana
        ventana = new Circulo(
            new Posicion(300, 350),
            8,
            new Borde(0, 0),
            color(255, 255, 180)
        );
    }

    @Override
    public void draw() {
        background(15, 15, 30);

        // Dibujar
        luna.dibujar(this);

        edificio1.dibujar(this);
        edificio2.dibujar(this);
        edificio3.dibujar(this);

        suelo.dibujar(this);
        ventana.dibujar(this);

        // ===== LUCES DE LOS EDIFICIOS =====
noStroke();

int[] xs = {150, 300, 450};   // centros de edificios
int[] anchos = {100, 120, 90};
int[] alturas = {300, 350, 280};

for (int i = 0; i < xs.length; i++) {
    float xCentro = xs[i];
    float ancho = anchos[i];
    float alto = alturas[i];

    for (float y = 300; y < 500; y += 30) {
        for (float x = -ancho/2 + 15; x < ancho/2 - 10; x += 25) {
            fill(255, 255, random(160, 220));
            circle(xCentro + x, y, 6);
        }
    }
}

    }
}

