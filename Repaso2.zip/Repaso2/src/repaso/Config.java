package repaso;

public class Config {
    public static final int ANCHO = 600;
    public static final int ALTO = 600;
}