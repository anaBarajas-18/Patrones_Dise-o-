/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import processing.core.PApplet;

public class Caja {
    protected Posicion posicion;
    protected Dimension dimension;
    protected Borde borde;
    protected int color;

    public Caja(Posicion posicion, Dimension dimension, Borde borde, int color) {
        this.posicion = posicion;
        this.dimension = dimension;
        this.borde = borde;
        this.color = color;
    }

    public void dibujar(PApplet p) {
        p.stroke(borde.getColor());
        p.strokeWeight(borde.getAncho());
        p.fill(color);
        p.rect(posicion.getX(), posicion.getY(),
               dimension.getAncho(), dimension.getAlto());
    }
}
