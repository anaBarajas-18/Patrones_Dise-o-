/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import processing.core.PApplet;

public class Circulo extends Caja {

    private float radio;

    public Circulo(Posicion posicion, float radio, Borde borde, int color) {
        super(posicion, null, borde, color);
        this.radio = radio;
    }

    @Override
    public void dibujar(PApplet p) {
        p.stroke(borde.getColor());
        p.strokeWeight(borde.getAncho());
        p.fill(color);
        p.circle(posicion.getX(), posicion.getY(), radio * 2);
    }
}
